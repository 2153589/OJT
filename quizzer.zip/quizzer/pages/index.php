﻿<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../css/main.css" type="text/css">
	<title>Webtek2k18</title>
<style>
body, html {
    height: 100%;
}

.parallax {
   

    /* Full height */
    height: 100%; 

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}


#ip1{

    background-image: url('../backgrounds/6.jpg');
	width: 100vw;
	height:100%;
	}
#ip2{
 
    background-image: url('../backgrounds/sample2.jpeg');
	width: 100vw;
	height:100%;
	}
#ip3{
 
    background-image: url('../backgrounds/9.jpeg');
	width: 100vw;
	height:100%;
	}
#ip4{

    background-image: url('../backgrounds/android.jpg');
	width: 100vw;
	height:100%;
	}
</style>
</head>
<body>
 <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	
	   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>
</div>
	   <?php  if (!isset($_SESSION['username'])) : ?>
    	
	<div class="parallax" id="ip1">

	<h2>Webtek 2k18</h2>
</div>
<?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<div class="parallax" id="ip1">

	<h2>Welcome <?php echo $_SESSION['username']; ?> to Webtek 2k18</h2>
</div>
    <?php endif ?>

 

<div class="container" id="iContainer1" >

<div id="text1"><p>
	
	 	
<br>		<i><h4>“Because they are designed to fulfill the Write, Once, Run Anywhere, promise 
		inherent in the Java programming language, Servlets can be executed 
		without modification on any platform."<h4><h5>-Oracle</h5></i></p>
		
		</div>
<iframe id="v1" src="https://www.youtube.com/embed/xGiRmweSO1g?autoplay=1">
</iframe>
</div>


<div class="parallax" id="ip2"></div>

<div class="container" id="iContainer2" >
<div id="text2">
	<h5>JSP</h5><p>
	 	The picture beside represents the summary on how JSP works. The client will request on the Server and later process everything until it will generate a response to the request of the Client.
	</p>
	</div>
<img id="image1" src="../images/JSP.jpg">
</img>
</div>


<div class="parallax" id="ip3"></div>

<div class="container" id="iContainer3" >
<div id="text3">
	<h5>MVC</h5><p>
	 	The MVC are built in order to improve the development aspect in creating an application.
Model-View-Controllers are the main components of this architectural pattern.

	</p>
	</div>
<img id="image1" src="../images/MVC.gif">
</img>
</div>

<div class="parallax" id="ip4">

<div id="back"><h4><a href="index.php" >Back to Top</a></h4></div>
</div>

</body>
</html>
