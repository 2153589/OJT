<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../css/forum.css" type="text/css">
	<title>Webtek2k18</title>
</head>
    <body>
        
 <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>

			   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>

</div>
<br>
<br>
<br>

<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="registration"; // Database name 
$tbl_name="fquestions"; // Table name 
$id=$_GET['id'];
// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// get value of id that sent from address bar 

$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=mysql_query($sql);
$rows=mysql_fetch_array($result);
?>

<table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor="1" >
<tr>
<td><strong><?php echo $rows['topic']; ?></strong></td>
</tr>

<tr>
<td><?php echo $rows['detail']; ?></td>
</tr>

<tr>
<td><strong>Date/time </strong><?php echo $rows['datetime']; ?></td>
</tr>
</table></td>
</tr>
</table>
<BR>
   


<?php

$tbl_name2="fanswer"; // Switch to table "forum_answer"
$sql2="SELECT * FROM $tbl_name2 WHERE question_id='$id'";
$result2=mysql_query($sql2);
while($rows=mysql_fetch_array($result2)){
?>

<table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1">

<tr>
<td width="23%"><strong>Name</strong></td>
<td width="77%"><?php echo $rows['a_name']; ?></td>
</tr>
<tr>
<td><strong>Answer</strong></td>
<td><?php echo $rows['a_answer']; ?></td>
</tr>
<tr>
<td><strong>Date/Time</strong></td>
<td><?php echo $rows['a_datetime']; ?></td>
</tr>
</table></td>
</tr>
</table><br>

<?php
}

$sql3="SELECT view FROM $tbl_name WHERE id='$id'";
$result3=mysql_query($sql3);
$rows=mysql_fetch_array($result3);
$view=$rows['view'];
if(empty($view)){
$view=1;
$sql4="INSERT INTO $tbl_name(view) VALUES('$view') WHERE id='$id'";
$result4=mysql_query($sql4);
}

$addview=$view+1;
$sql5="update $tbl_name set view='$addview' WHERE id='$id'";
$result5=mysql_query($sql5);
mysql_close();
?>
 <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<br>
	<h2 align ="center" style="color:#DCDCDC">Login to add an answer</h2>
	<h2 align ="center"><a href="login.php">click here to log in</a></h2>

<?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	   
<BR>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<form name="form1" method="post" action="add_answer.php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td width="21%"><strong>Name</strong></td>
<td width="79%"><input name="a_name" type="text" value = "<?php echo $_SESSION['username']; ?>" size="45"></td>
</tr>
<tr>
<td valign="top"><strong>Answer</strong></td>

<td><textarea name="a_answer" cols="45" rows="3" id="a_answer"></textarea></td>
</tr>
<tr>

<td><input name="id" type="hidden" value="<?php echo $id; ?>"></td>
<td><input type="submit" name="Submit" value="Submit"> <input type="reset" name="Submit2" value="Reset"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<?php endif ?>
</body>
</html>