<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign-up</title>
		<link rel="stylesheet" type="text/css" href="../css/style.css">
  
 
  </head>
 
  <body>
    <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="topics.php">Finals</a>
	<a href="forum.html">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	
	<a href="login.php">Login/Sign up</a>
	
</div>
      <div class="fade">
	  
      </div>
	  
   <div class="inputs">
   
           <form method = "post" class="forms" action="register.php">
		   <?php include('errors.php'); ?>
		   
		<input type = "text" name="username" placeholder ="user name"/>
         <input type = "password" name="password_1" placeholder ="password"/>
		 <input type = "password" name="password_2" placeholder ="confirm password"/>
         <input type = "email" name="email" placeholder ="email id"/>
      <button type ="submit" class="btn" name="reg_user">Create </button>
      <p class = "message"> Already Registered?<a href = "login.php">Login</a>
      </p>
	  </form>
	  </div>
      
  </body>
</html>