<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../css/forum.css" type="text/css">
	<title>Webtek2k18</title>
</head>
    <body>
        
 <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	

			   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>


</div>


<br>
<br>
<br>
<br>



<?php

$host="localhost"; 
$username="root";  
$password=""; 
$db_name="registration"; 
$tbl_name="fquestions"; 


mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

$sql="SELECT * FROM $tbl_name ORDER BY id DESC";
$result=mysql_query($sql);
?>

<table width="90%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC" >
<tr>

<td width="53%" align="center"><strong>Topic</strong></td>
<td width="15%" align="center"><strong>Views</strong></td>
<td width="13%" align="center"><strong>Replies</strong></td>
<td width="13%" align="center"><strong>Date/Time</strong></td>
</tr>

<?php

while($rows = mysql_fetch_array($result)){
?>
<tr>
<td ><a href="view_topic.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['topic']; ?></a><BR></td>
<td align="center"><?php echo $rows['view']; ?></td>
<td align="center"><?php echo $rows['reply']; ?></td>
<td align="center"><?php echo $rows['datetime']; ?></td>
</tr>

<?php
}
mysql_close();
?>




   
<?php  if (!isset($_SESSION['username'])) : ?>
		
	<h2 align ="center" style="color:#DCDCDC">Login to create a topic</h2>
	<h2 align ="center"><a href="login.php">click here to log in</a></h2>

<?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>

<tr> 
<td colspan="5" align="right" bgcolor="#E6E6E6"><a href="new_topic.php"><strong>Create New Topic</strong> </a></td>
<?php endif ?>

</tr>
</table>
</body>
</html>