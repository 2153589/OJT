<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
  <head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
		<link rel="stylesheet" type="text/css" href="../css/style.css">
  
 
  </head>
 
  <body>
  <div id="nav">
	
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	
	 <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>
	
</div>
    
      <div class="fade">
	  
      </div>
	  
  <div class="inputs">
<form method="post" class= "forms" action="login.php">
<?php include('errors.php'); ?>
    <input type = "text" name="username" placeholder ="user name"/>
    <input type = "password" name="password" placeholder ="password"/>
	<input type= "submit" class="btn" name="login_user" value="login">
      <p class = "message">
        Not registered?<a href="register.php">Register</a>
      </p>
	  </div>
</form>
      
  </body>
</html>