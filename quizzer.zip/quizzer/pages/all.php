<?php include 'database.php'; ?>
<?php session_start(); ?>
<?php


//Getting question and choices
$query = "SELECT * FROM `questions` join `choice` on questions.question_num=choice.question_num where choice.is_correct = 1";


//get result for question
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
//$question = $result->fetch_assoc();




?>
<!DOCTYPE html>
<html>
<body>


	<main>
		<table border = 1 cellpadding=1 cellspacing=1>
			<th>Question</th>
			<th>Description</th>
			<th>Correct answer</th>

			<?php 
	if($result->num_rows>0){
	while($row = $result->fetch_assoc() ){
		
		echo "<tr>";
		echo "<td>". $row["question_num"] . "</td>" ;
		echo "<td>". $row["description"] . "</td>" ;
		echo "<td>". $row["text"] . "</td>" ;
		

	}
}else{
		echo "No Questions";
}
			?>
			
		</table>

	
	</main>

</body>
</html>