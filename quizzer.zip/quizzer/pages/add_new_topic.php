<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../css/forum.css" type="text/css">
	<title>Webtek2k18</title>
</head>
    <body>
        
 <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	

			   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>

</div>


<br>
<br>
<br>
<br>

<?php

$host="localhost"; 
$username="root";  
$password="";  
$db_name="registration";
$tbl_name="fquestions"; 

mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
 
$topic=$_POST['topic'];
$detail=$_POST['detail'];
$name=$_POST['name'];


$datetime=date("d/m/y h:i:s"); 

$sql="INSERT INTO $tbl_name(topic, detail, name, datetime)VALUES('$topic', '$detail', '$name',  '$datetime')";
$result=mysql_query($sql);

if($result){
echo "<p align='center' style='color:#DCDCDC;font-size:20px'>"."Your Topic have been Successfully Added!<BR>"."</p>";
echo "<p align='center'>"."<a href=main_forum.php>View your topic</a>"."</p>";
}
else {
echo "ERROR";
}
mysql_close();
?>
</body>
</html>