<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="../css/forum.css" type="text/css">
	<title>Webtek2k18</title>
</head>
    <body>
        
 <div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	

			   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>

</div>
<br>
<br>
<br>
<div></div>

<div class="placeholder" id="p1">
<div id="hd1">
		<p>Create A Topic</p>
		</div>
	
	


<table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<form id="form1" name="form1" method="post" action="add_new_topic.php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1">
<tr>
<td colspan="3"><strong>Create New Topic</strong> </td>
</tr>
<tr>
<td width="16%"><strong>Topic</strong></td>
<td width="84%"><input name="topic" type="text" id="topic" size="50" /></td>
</tr>
<tr>
<td valign="top"><strong>Detail</strong></td>
<td><textarea name="detail" cols="50" rows="3" id="detail"></textarea></td>
</tr>
<tr>
<td><strong>Name</strong></td>
<td><input name="name" type="text" value = "<?php echo $_SESSION['username']; ?>" size="50" /></td>
</tr>
<tr>
<td>&nbsp;</td>

<td><input type="submit" name="Submit" value="Submit" /> 
<input type="reset" name="Submit2" value="Reset" /></td>
</tr>
</table>
</td>
</form>
</tr>
</table>

</body>
</html>