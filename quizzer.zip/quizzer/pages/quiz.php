<?php include 'database.php'; ?>
<?php
// total number question
$query = "Select * from questions";
// Results
$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
$total = $result->num_rows;

?>
<?php 
  session_start(); 
  ?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="../css/main.css" type="text/css">
<style>
ul{
	list-style: none;
}
 body{
    font-size: 20px;
    color: #333;
  font-weight: 300;
  text-align: center;
  background-color: #f8f6f0;
}

</style>

<body>
<div id="nav">
	
	<a href="index.php">Home</a>
	<a href="main_forum.php">Forum</a>
	<a href="quiz.php">Quiz Now</a>
	
		   <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>
	
</div>


	<main>
		<?php  if (!isset($_SESSION['username'])) : ?>
    	
		<br>
	<h2>Please Log in to take the quiz</h2>
	<h2><a href="login.php">click here to log in</a></h2>

<?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
	<br>
	<h2>Quiz</h2>

		
	<ul>
		<li><b>Number of Questions: </b><?php echo $total?></li>
		<li><b>TYPE: </b> Multiple choice</li>
	</ul>
	<a href="question.php?n=1" > Attempt quiz</a>
    <?php endif ?>

	</main>

</body>
</html>