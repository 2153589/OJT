-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 19, 2018 at 02:25 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `choice`
--

CREATE TABLE IF NOT EXISTS `choice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_num` int(11) NOT NULL,
  `is_correct` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `choice`
--


-- --------------------------------------------------------

--
-- Table structure for table `fanswer`
--

CREATE TABLE IF NOT EXISTS `fanswer` (
  `question_id` int(4) NOT NULL DEFAULT '0',
  `a_id` int(4) NOT NULL DEFAULT '0',
  `a_name` varchar(65) NOT NULL DEFAULT '',
  `a_answer` longtext NOT NULL,
  `a_datetime` varchar(25) NOT NULL DEFAULT '',
  KEY `a_id` (`a_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fanswer`
--

INSERT INTO `fanswer` (`question_id`, `a_id`, `a_name`, `a_answer`, `a_datetime`) VALUES
(4, 1, 'pogiko', 'this and that test', '13/05/18 08:54:28'),
(5, 1, 'test', 'I do not kow', '13/05/18 10:23:47'),
(5, 2, 'Anonymous', 'With hard work and determination, you can pass that subject :D', '13/05/18 10:40:42'),
(9, 1, 'test', 'You can try reading "the lioness song" series', '13/05/18 13:30:17'),
(3, 1, 'jargon', 'Test answer', '13/05/18 13:34:31'),
(3, 2, 'jargon', 'testing center message', '13/05/18 13:37:23'),
(3, 3, 'jargon', 'another test', '13/05/18 13:39:24'),
(3, 4, 'jargon', 'aaaaaaaaaaa', '13/05/18 13:40:03'),
(0, 1, '', '', '13/05/18 13:45:40'),
(3, 5, 'jargon', 'final testtt', '13/05/18 13:46:01'),
(3, 6, 'jargon', 'final testtt', '13/05/18 13:49:01'),
(3, 7, 'jargon', 'PLEASE GUMANA KA NAAA', '13/05/18 13:52:23'),
(3, 8, 'jargon', 'YESSSS', '13/05/18 13:54:49'),
(3, 9, 'jargon', 'Please', '13/05/18 13:55:40');

-- --------------------------------------------------------

--
-- Table structure for table `fquestions`
--

CREATE TABLE IF NOT EXISTS `fquestions` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL,
  `name` varchar(65) NOT NULL DEFAULT '',
  `datetime` varchar(25) NOT NULL DEFAULT '',
  `view` int(4) NOT NULL DEFAULT '0',
  `reply` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `fquestions`
--

INSERT INTO `fquestions` (`id`, `topic`, `detail`, `name`, `datetime`, `view`, `reply`) VALUES
(3, 'test', 'test test test', 'tes2', '13/05/18 08:43:24', 18, 9),
(5, 'How can I pass this subject?', 'I want to pass, please?', 'this', '13/05/18 10:23:20', 8, 2),
(9, 'Books to read', 'Can anyone suggest a book that I can read? \r\nAlong with the lines of medieval-fantasy or Sci-Fi\r\nTHANKS!', 'jargon', '13/05/18 01:27:25', 10, 2),
(10, 'Final Test', 'This is the final test, please do not reply. This is only a test', 'jargon', '13/05/18 01:56:31', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `question_num` int(11) NOT NULL,
  `description` text NOT NULL,
  `topic_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_name` varchar(45) NOT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`topic_id`, `topic_name`) VALUES
(1, 'JSP'),
(2, 'Servlets'),
(3, 'PHP'),
(4, 'Node'),
(5, 'WAS'),
(6, 'CGI'),
(7, 'ASP');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'weng', 'weng.great@gmail.com', '202cb962ac59075b964b07152d234b70'),
(2, 'weng12', 'weng1.great@gmail.com', '202cb962ac59075b964b07152d234b70'),
(3, 'weng123', 'weng12.great@gmail.com', '202cb962ac59075b964b07152d234b70'),
(4, 'april', 'april@april.com', '202cb962ac59075b964b07152d234b70'),
(5, 'test', 'test@gmail.com', '098f6bcd4621d373cade4e832627b4f6'),
(6, 'jones', 'jones@youmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(7, 'jargon', 'jargon@yahoo.com', '93fd31799572add89a43347b2edc5293');
