Since the technology that was used is PHP and we used Wamp Server
*Install First Wamp Server

> First run Wamp Server
> Second, import the 'registration.sql' file in the database (Use MySql or phpMyAdmin for the database)
> Third, go to the 'C:' directory and go the 'wamp' folder, then to the 'www' folder, then copy/cut and paste the Website Folder (9340A-G2) here
> Fourth, Open a browser (Recommended Browser: Google Chrome)
> Finally, put this url of the in the search bar: 'localhost/9340A-G2/pages/index.php'
	to start the website.

*There is need for an Internet Connection for the videos in the website to play.